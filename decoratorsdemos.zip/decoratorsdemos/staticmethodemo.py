


'''
the @classmethod decorator is used to declare a method in the class as a class method
 that can be called using ClassName.MethodName(). The class method can also be called using an object of the class.

@classmethod Characteristics
Declares a class method.
The first parameter must be cls, which can be used to access class attributes.
The class method can only access the class attributes but not the instance attributes.
The class method can be called using ClassName.MethodName() and also using object.
It can return an object of the class. 
#The class method can only access class attributes, but not the instance attributes
'''


class Student:
    name = 'unknown' # class attribute
    def __init__(self):
        self.age = 20  # instance attribute

    @classmethod
    def tostring(cls):
        print('Student Class Attributes: name=',cls.name)
        
        
Student.tostring()


#the same method can be called using an object also.
std = Student()
std.tostring() 
Student().tostring() 