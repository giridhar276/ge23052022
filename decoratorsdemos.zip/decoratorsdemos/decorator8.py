'''
When you wrap a function using decorator the attributes of original function such as __doc__ (docstring), __name__(name of the function), __module__(module in which the function is defined) will be lost.
Although you can overwrite them in the decorator function python has a built-in decorator @wraps to do it

'''


from functools import wraps

def func_name_printer(func):
    @wraps(func)
    def wrapper(*args):
        """Prints the Name of the function.
        """
        print("Function that started running is " + func.__name__)
        result = func(*args)
        return result # Extra Return 
    return wrapper

@func_name_printer
def add(*args):
    """
    Args: Tuple of Numbers:
    Returns: Sum of the numbers in Tuple
    """
    tot_sum = 0
    for arg in args:
        tot_sum += arg
    return "result = " + str(tot_sum)

print(add.__name__)
print(add.__doc__)
print(add.__module__)

print(add(5,6,7))