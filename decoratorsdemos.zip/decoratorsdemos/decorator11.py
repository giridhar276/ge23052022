
'''
Making it faster with deco
Using deco, there are two things we need to do in order to speed up our previous example script.

First we decorate the ping() function with @concurrent. After this, we create a function that executes the ping() function for every host in a list. In that function, we collect the results of the now decorated ping() function. All the results of the ping() function are returned as a list.
'''


import os
import subprocess
from deco import concurrent, synchronized

@concurrent
def ping(host):
    '''
    Sends 2 ICMPs to a host and suppress the output by sending it to devnull.
    
    Returns True if there was a response, False otherwise.
    '''
    with open(os.devnull, 'w') as devnull:
        result = subprocess.call(
            ['ping', '-c', '2', '-W', '2', host],
            stdout=devnull,
            stderr=devnull
            )
            
    if result == 0:
        return True
    else:        
        return False


@synchronized
def ping_list(host_list):
    """
    Runs ping() against a list of hosts in parallel and returns the
    results as a list.
    """
    ping_returns = [ ping_return.get()[0] for ping_return in map(ping, host_list)]    
        
    return ping_returns

host_list = [ 'server-{}'.format(nr) for nr in range(0, 10) ]

print(ping_list(host_list))