#######################
def first(msg):
    print(msg)


first("Hello")

second = first
second("Hello")


print(id(second))
print(id(first))
########################

val = 10
aval = 10
print(id(val))
print(id(aval))




















########################
#Functions can be passed as arguments to another function.
def inc(x):
    return x + 1


def dec(x):
    return x - 1


def operate(func, x):
    result = func(x)
    return result

print(operate(inc,3))

print(operate(dec,3))
########################



########################
#a function can return another function.
#is_returned() is a nested function which is 
#defined and returned each time we call is_called().
def is_called():
    def is_returned():
        print("Hello")
    return is_returned

new = is_called()
# Outputs "Hello"
new()
########################



#########################################################################
#Basically, a decorator takes in a function, 
#adds some functionality and returns it.
def make_pretty(func):
    def inner():
        print("I got decorated")
        func()  # original functinality
        print("I got decorated")
    return inner


def ordinary():
    print("I am ordinary")


#make_pretty() is a decorator
# let's decorate this ordinary functio
pretty = make_pretty(ordinary)
pretty()







#The function ordinary() got decorated and the returned function was given the name pretty.
#We can see that the decorator function added some new functionality to the original function
#The decorator acts as a wrapper. 
#########################################################################





#########################################################################
#Python has a syntax to simplify this.
#We can use the @ symbol along with the name of the decorator function and place it above the definition of the function to be decorated.

def make_pretty(func):
    def inner():
        print("I got decorated")
        func()
    return inner

@make_pretty
def ordinary():
    print("I am ordinary")

ordinary()
#########################################################################



#########################################################################
#Decorating Functions with Parameters
def divide(a, b):
    return a/b
print(divide(2,5))
print(divide(2,0))
#########################################################################




#########################################################################
#parameters of the nested inner() function inside the decorator is the same as the parameters of functions it decorates. 
def smart_divide(func):
    def inner(a, b):
        print("I am going to divide", a, "and", b)
        if b == 0:
            print("Whoops! cannot divide")
            return

        return func(a, b)
    return inner


@smart_divide
def divide(a, b):
    print(a/b)
    
    
divide(2,5)
divide(2,0)
#########################################################################









#########################################################################
#Chaining Decorators in Python




def star(func):
    def inner(*args, **kwargs):
        print("*" * 30)
        func(*args, **kwargs)
        print("*" * 30)
    return inner

def percent(func):
    def inner(*args, **kwargs):
        print("%" * 30)
        func(*args, **kwargs)
        print("%" * 30)
    return inner

@star
@percent
def printer(msg):
    print(msg)

printer("Hello")




'''
def printer(msg):
    print(msg)
printer = star(percent(printer))
'''




@percent
@star
def printer(msg):
    print(msg)









def p_decorate(func):
   def func_wrapper(name):
       return "<p>{0}</p>".format(func(name))
   return func_wrapper

#@p_decorate
def get_text(name):
   return "lorem ipsum, {0} dolor sit amet".format(name)

print(get_text("John"))









def p_decorate(func):
   def func_wrapper(name):
       return "<p>{0}</p>".format(func(name))
   return func_wrapper

def strong_decorate(func):
    def func_wrapper(name):
        return "<strong>{0}</strong>".format(func(name))
    return func_wrapper

def div_decorate(func):
    def func_wrapper(name):
        return "<div>{0}</div>".format(func(name))
    return func_wrapper


@div_decorate
@p_decorate
@strong_decorate
def get_text(name):
    return "lorem ipsum, {0} dolor sit amet".format(name)

# Basic approach would be:
# get_text = div_decorate(p_decorate(strong_decorate(get_text)))

print(get_text("John"))









def func_name_printer(func):
    def wrapper(*args):
        print("Function that started running is " + func.__name__)
        func(*args)
    return wrapper

@func_name_printer
def add(*args):
    tot_sum = 0
    for arg in args:
        tot_sum += arg
    print("result = " + str(tot_sum))
    
@func_name_printer
def sub(*args):
    tot_sub = args[0]-args[1]
    print("result = " + str(tot_sub))

@func_name_printer
def mul(*args):
    tot_mul = 1
    for arg in args:
        tot_mul *= arg
    print("result = " + str(tot_mul))   
    
add(1,2)
mul(1,2,3)
sub(400, 150)
















import time

def timeit(func):
    def wrapper(*args, **kwargs):
        print("Tracking function: " + func.__name__ + "()")
        start = time.time()
        func(*args, **kwargs)
        end = time.time()
        print("Time taken by the function to run is " + str(end-start))
    return wrapper

@timeit
def looper(*args, **kwargs):
    print(f"args = {args}")
    print(f"kwargs = {kwargs}")
    
    for loop in kwargs.values(): 
        for i in range(loop):
            return i

looper(2, 3, 4, loop1=10, loop2=11, loop3=12, loop4=15)













































